$Id: README,v 1.2 2002/12/09 16:29:44 mike Exp $

In this directory, we test the integrity of the CQL-Java tools as
follows:

* Generate a random tree with CQLGenerate
* Take a copy
* Canonicalise it with CQLparser -c.
* Compare the before-and-after versions.

Since the CQLGenerate output is in canonical form anyway, the
before-and-after versions should be identical.  This process exercises
the comprehensiveness and bullet-proofing of the parser, as well as
the accuracy of the rendering.


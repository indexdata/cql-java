#!/bin/sh

# Trivial script to invoke the CQLLexer test-harness

[ -r /usr/share/java-utils/java-functions ] && . /usr/share/java-utils/java-functions || exit 1
set_javacmd || exit 3
check_java_env || exit 4
set_jvm_dirs || exit 5

set_classpath cql-java

MAIN_CLASS="org.z3950.zing.cql.CQLLexer"

run $@
